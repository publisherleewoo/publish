  function selectBoxFunc(selectBox, divTarget) {

                var $select = $(selectBox)
                var $option = $select.find('option')
                var $selectBoxStyle = $(divTarget)
                var $selectBoxStyleheight = 0;

                $selectBoxStyle.append('<div>' + '　' + '</div>')
                $select.css({
                    'position': 'absolute',
                    'left': '-9999px',
                    'z-index': '-1px'
                })
                var selectBoxHeightSetting = function () {
                    $selectBoxStyle.css({
                        'height': $selectBoxStyle.find('>div').eq(1).height(),
                        'overflow': 'hidden'
                    })
                }
                $option.each(function (idx, el) {
                    $selectBoxStyle.append('<div>' + el.innerHTML + '</div>')
                })
                $selectBoxStyle.find('>div').each(function () {
                    $selectBoxStyleheight += $(this).height()
                })
                selectBoxHeightSetting()
                $selectBoxStyle.on('click', function (e) {
                    e.stopPropagation()
                    console.log($(this))
                    $(this).css({
                        'height': $selectBoxStyleheight,
                        'overflow': 'visiable'
                    })

                    var $div = $(this).find('>div')

                    $div.not(':eq(0)').on('mouseover', function () {
                        $selectBoxStyle.find('>div').css({ 'background': 'trasnparent' })
     

                    })

                    $div.on('click', function (e) {
                        e.stopPropagation()
                        var idx = $(this).index()
                        var text = $(this).text();
                        $option.eq(idx - 1).prop('selected', true)
                        $div.off('mouseover click')
                        $selectBoxStyle.find('>div').eq(0).text(text)
                        selectBoxHeightSetting()
                    })

                }).mouseleave(function () {
                    selectBoxHeightSetting()
                })
            }